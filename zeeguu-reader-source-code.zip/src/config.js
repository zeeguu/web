const WEB_URL = "https://www.zeeguu.org";
const WEB_LOGIN_URL = "https://www.zeeguu.org/log_in";
const API_URL = "https://api.zeeguu.org";

export { WEB_URL, API_URL, WEB_LOGIN_URL };
