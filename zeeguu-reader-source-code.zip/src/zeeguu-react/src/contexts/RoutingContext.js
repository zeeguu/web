import { createContext } from "react";

export const RoutingContext = createContext(null);
