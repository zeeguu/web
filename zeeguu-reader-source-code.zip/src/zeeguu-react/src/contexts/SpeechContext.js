import { createContext } from "react";

export const SpeechContext = createContext(1);
