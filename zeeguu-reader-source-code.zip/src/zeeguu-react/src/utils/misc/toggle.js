export default function toggle(state, togglerFunction) {
  togglerFunction(!state);
}
