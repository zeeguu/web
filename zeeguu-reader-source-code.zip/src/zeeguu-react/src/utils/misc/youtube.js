function extractVideoIDFromURL(url) {
  return url.split("=")[1];
}

export { extractVideoIDFromURL };
