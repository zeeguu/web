import styled from "styled-components";

const Interests = styled.div`
  margin-bottom: 1em;
  margin-left: 1em;
  display: inline-block;
`;
export { Interests };
