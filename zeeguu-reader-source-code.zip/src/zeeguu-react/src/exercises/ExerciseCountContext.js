import { createContext } from "react";

export const ExerciseCountContext = createContext(1);
