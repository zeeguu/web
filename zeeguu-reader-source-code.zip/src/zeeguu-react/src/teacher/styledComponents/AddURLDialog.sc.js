import styled from "styled-components";

export const StyledURLDialog = styled.div`
  .add-text-headline {
    text-align: center;
  }
`;
