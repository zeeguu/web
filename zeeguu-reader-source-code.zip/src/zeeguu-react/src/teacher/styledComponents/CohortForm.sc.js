import styled from "styled-components";

export const StyledCohortForm = styled.div`
  .form-control {
    min-width: "120";
  }
`;
