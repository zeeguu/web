import styled from "styled-components";
import "@reach/accordion/styles.css";

export const StyledMyTexts = styled.div`
  .sorting-btns-box {
    display: flex;
    width: 100%;
    justify-content: flex-end;
  }
`;
