import styled from "styled-components";

export const StyledStudentExercisesInsights = styled.div`
  .exercise-insight-sections {
    display: flex;
    flex-direction: row;
    justify-content: center;
    margin-top: 2em;
    margin-left: 1.5%;
  }
`;
