import { css } from "styled-components";

let horizontalCentering = css`
  margin-left: auto;
  margin-right: auto;
`;

export { horizontalCentering };
