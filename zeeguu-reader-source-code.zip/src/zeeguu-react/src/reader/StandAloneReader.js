import ArticleReader from "./ArticleReader";

export default function StandAloneReader({ api }) {
  return <ArticleReader api={api} />;
}
