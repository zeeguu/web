import * as s from "./Logo.sc";

export default function Logo() {
  return <s.Logo src="../static/images/zeeguuLogo.svg" alt=""></s.Logo>;
}
