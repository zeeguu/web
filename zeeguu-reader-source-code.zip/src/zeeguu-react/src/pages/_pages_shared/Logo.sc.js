import styled from "styled-components";

const Logo = styled.img`
  width: 2.25rem;
`;

export { Logo };
