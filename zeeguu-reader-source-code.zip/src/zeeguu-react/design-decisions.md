
# Why not add explanations instead of translations?
In discussions with language teachers we have heard that they prefer to explain also in the learned language and they never translate. 
This is something that seems easier in theory than in practice. 
In practice a dictionary page can be very long, and reading it can be quite disturbing for the flow of the reader if the reader has to lookup more than a word.


# Can we show texts to readers without showing them the original source? 

